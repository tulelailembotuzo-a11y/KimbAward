-- =====================================================================
-- LimbApp : tests.sql  (à lancer APRÈS database.sql)
-- Ne laisse aucune donnée : tout est annulé à la fin (ROLLBACK).
-- Succès = deux messages : « TOUS LES TESTS SONT OK » puis
-- « TOUS LES TESTS DE L'ETAPE 3 SONT OK ».
-- =====================================================================

begin;

do $$
declare
  c uuid; a uuid; b uuid; b1 uuid; b2 uuid;
  n bigint; r int; w uuid;
begin
  -- Test 3 : dimanche 23 h 59 (Burundi) = semaine qui se termine
  --          11 janv. 2026, 21:59 UTC = 23:59 au Burundi
  assert public.bj_week_start('2026-01-11 21:59:00+00') = date '2026-01-05',
    'ECHEC test 3 : dimanche 23h59 doit appartenir a la semaine du 5 janvier';

  -- Test 4 : lundi 00 h 00 = nouvelle semaine
  assert public.bj_week_start('2026-01-11 22:00:00+00') = date '2026-01-12',
    'ECHEC test 4 : lundi 00h00 doit ouvrir la semaine du 12 janvier';

  -- Données de test
  insert into public.categories (slug, name, sort_order) values ('zz-test', 'Test', 999) returning id into c;
  insert into public.candidates (category_id, name, is_published) values (c, 'A', true) returning id into a;
  insert into public.candidates (category_id, name, is_published) values (c, 'B', true) returning id into b;

  -- Test 1 : un appareil vote une fois, le vote est enregistré (semaine 1)
  insert into public.ballots (device_id, created_at) values ('device-test-0001', '2026-01-11 21:59:00+00') returning id into b1;
  insert into public.votes (ballot_id, candidate_id, category_id) values (b1, a, c);
  select count(*) into n from public.votes where category_id = c;
  assert n = 1, 'ECHEC test 1 : le vote n''est pas enregistre';

  -- Test 2 : même appareil, même semaine : refusé
  begin
    insert into public.ballots (device_id, created_at) values ('device-test-0001', '2026-01-08 10:00:00+00');
    raise exception 'ECHEC test 2 : le doublon a ete accepte';
  exception when unique_violation then
    raise notice 'OK test 2 : doublon refuse';
  end;

  -- Test 4 (suite) : même appareil, semaine suivante : accepté
  insert into public.ballots (device_id, created_at) values ('device-test-0001', '2026-01-11 22:00:00+00') returning id into b2;
  insert into public.votes (ballot_id, candidate_id, category_id) values (b2, b, c);

  -- Compteur hebdomadaire : repart de zéro chaque semaine
  select votes into n from public.compute_results('week', date '2026-01-05') where candidate_id = a;
  assert n = 1, 'ECHEC : A doit avoir 1 vote en semaine 1';
  select votes into n from public.compute_results('week', date '2026-01-05') where candidate_id = b;
  assert n = 0, 'ECHEC : B doit avoir 0 vote en semaine 1';
  select votes into n from public.compute_results('week', date '2026-01-12') where candidate_id = a;
  assert n = 0, 'ECHEC test 4 : le compteur de A doit repartir de zero';
  select votes into n from public.compute_results('week', date '2026-01-12') where candidate_id = b;
  assert n = 1, 'ECHEC : B doit avoir 1 vote en semaine 2';

  -- Tests 5, 6, 7 : le mois et l'année cumulent toutes les semaines
  select votes into n from public.compute_results('month', date '2026-01-01') where candidate_id = a;
  assert n = 1, 'ECHEC test 6 : le mois doit compter le vote de A';
  select votes into n from public.compute_results('month', date '2026-01-01') where candidate_id = b;
  assert n = 1, 'ECHEC test 6 : le mois doit compter le vote de B';
  select votes into n from public.compute_results('year', date '2026-01-01') where candidate_id = a;
  assert n = 1, 'ECHEC test 7 : l''annee doit compter le vote de A';

  -- Égalité : « premier arrivé, premier servi » (A a voté avant B)
  select rank into r from public.compute_results('month', date '2026-01-01') where candidate_id = a;
  assert r = 1, 'ECHEC : en cas d''egalite, A (arrive en premier) doit etre classe 1er';

  -- Pourcentage : base 100 % sur la catégorie
  select percent into n from public.compute_results('month', date '2026-01-01') where candidate_id = a;
  assert n = 50, 'ECHEC : A doit avoir 50 % (1 vote sur 2)';

  -- Test 8 : ajouter un candidat ne supprime rien
  insert into public.candidates (category_id, name, is_published) values (c, 'C', true);
  select votes into n from public.compute_results('month', date '2026-01-01') where candidate_id = a;
  assert n = 1, 'ECHEC test 8 : l''ajout d''un candidat a modifie les votes';

  -- Test 9 : masquer les compteurs ne modifie pas les données
  update public.settings set show_counters = false where id = 1;
  select votes into n from public.public_results('month', date '2026-01-01') where candidate_id = a;
  assert n is null, 'ECHEC test 9 : le compteur public devrait etre masque';
  select votes into n from public.compute_results('month', date '2026-01-01') where candidate_id = a;
  assert n = 1, 'ECHEC test 9 : le vote doit toujours etre calcule';
  update public.settings set show_counters = true where id = 1;

  -- Test 10 : publier un gagnant ne supprime pas les votes
  perform public.compute_winners('week', date '2026-01-05');
  select candidate_id into w from public.winners
    where period_type = 'week' and period_start = date '2026-01-05' and category_id = c;
  assert w = a, 'ECHEC test 10 : le gagnant de la semaine 1 doit etre A';
  select count(*) into n from public.votes where category_id = c;
  assert n = 2, 'ECHEC test 10 : des votes ont disparu';

  -- Gagnant du mois : égalité départagée en faveur de A
  perform public.compute_winners('month', date '2026-01-01');
  select candidate_id into w from public.winners
    where period_type = 'month' and period_start = date '2026-01-01' and category_id = c;
  assert w = a, 'ECHEC : le gagnant du mois doit etre A (premier arrive)';

  -- Historique protégé : modification et suppression des votes interdites
  begin
    update public.votes set candidate_id = candidate_id where category_id = c;
    raise exception 'ECHEC : modification d''un vote acceptee';
  exception when raise_exception then
    if sqlerrm like 'ECHEC%' then raise; end if;
    raise notice 'OK : modification des votes refusee';
  end;
  begin
    delete from public.votes where category_id = c;
    raise exception 'ECHEC : suppression d''un vote acceptee';
  exception when raise_exception then
    if sqlerrm like 'ECHEC%' then raise; end if;
    raise notice 'OK : suppression des votes refusee';
  end;

  raise notice 'TOUS LES TESTS SONT OK';
end $$;

rollback;

begin;
do $$
declare c uuid; a uuid; b uuid; c2 uuid; x uuid; r jsonb; n bigint;
begin
  insert into public.categories (slug, name, sort_order) values ('zz-t1', 'T1', 998) returning id into c;
  insert into public.categories (slug, name, sort_order) values ('zz-t2', 'T2', 999) returning id into c2;
  insert into public.candidates (category_id, name, is_published) values (c, 'A', true) returning id into a;
  insert into public.candidates (category_id, name, is_published) values (c2, 'B', true) returning id into b;
  insert into public.candidates (category_id, name, is_published) values (c, 'Cache', false) returning id into x;

  r := public.cast_vote('appareil-test-0001', 'iphash1', jsonb_build_object(c::text, a::text));
  assert (r->>'ok')::boolean, 'ECHEC test 1 : vote refuse : ' || r::text;
  r := public.cast_vote('appareil-test-0001', 'iphash1', jsonb_build_object(c::text, a::text));
  assert r->>'reason' = 'already_voted', 'ECHEC test 2 : 2e vote non refuse';
  r := public.cast_vote('appareil-test-0002', 'iphash1', jsonb_build_object(c::text, x::text));
  assert r->>'reason' = 'invalid_choice', 'ECHEC : candidat masque accepte';
  r := public.cast_vote('appareil-test-0002', 'iphash1', jsonb_build_object(c::text, b::text));
  assert r->>'reason' = 'invalid_choice', 'ECHEC : candidat d''une autre categorie accepte';
  r := public.cast_vote('appareil-test-0002', 'iphash1', jsonb_build_object(c::text, a::text, c2::text, b::text));
  assert (r->>'ok')::boolean, 'ECHEC : vote multi-categories refuse';
  r := public.cast_vote('court', null, jsonb_build_object(c::text, a::text));
  assert r->>'reason' = 'invalid', 'ECHEC : identifiant trop court accepte';
  select count(*) into n from public.votes where category_id = c;
  assert n = 2, 'ECHEC : 2 votes attendus dans T1, trouve ' || n;
  r := public.chat_send('visiteur-test-00001', 'iphash1', 'Bonjour');
  assert (r->>'ok')::boolean, 'ECHEC : message refuse';
  assert jsonb_array_length(public.chat_list('visiteur-test-00001')) = 1, 'ECHEC : message non lu';
  raise notice 'TOUS LES TESTS DE L''ETAPE 3 SONT OK';
end $$;
rollback;
