-- =====================================================================
-- LimbApp : database.sql  (UN SEUL FICHIER pour toute la base de données)
-- À coller dans Supabase > SQL Editor > New query > Run  (une seule fois)
-- Contient : tables, calendrier du Burundi (UTC+2), règles de vote,
-- résultats, gagnants automatiques, messages, sécurité, photos, catégories
-- de départ et tâche automatique.
-- Semaine = lundi 00 h 00 -> dimanche 23 h 59.
-- =====================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------------
-- 1. CALENDRIER (toujours calculé côté serveur)
-- ---------------------------------------------------------------------
create or replace function public.bj_week_start(ts timestamptz) returns date
language sql stable as
$$ select date_trunc('week', ts at time zone 'Africa/Bujumbura')::date $$;

create or replace function public.bj_month_start(ts timestamptz) returns date
language sql stable as
$$ select date_trunc('month', ts at time zone 'Africa/Bujumbura')::date $$;

create or replace function public.bj_year_start(ts timestamptz) returns date
language sql stable as
$$ select date_trunc('year', ts at time zone 'Africa/Bujumbura')::date $$;

-- Fin d'une période (instant exact où elle se termine, heure du Burundi)
create or replace function public.bj_period_end(p_period text, p_start date) returns timestamptz
language sql stable as
$$ select ((p_start + case p_period
                        when 'week'  then interval '7 days'
                        when 'month' then interval '1 month'
                        else interval '1 year' end)::timestamp)
          at time zone 'Africa/Bujumbura' $$;

-- ---------------------------------------------------------------------
-- 2. TABLES
-- ---------------------------------------------------------------------

-- Réglages du site (une seule ligne)
create table if not exists public.settings (
  id              int primary key default 1 check (id = 1),
  whatsapp        text not null default '',
  email           text not null default '',
  show_counters   boolean not null default true,
  show_rankings   boolean not null default true,
  updated_at      timestamptz not null default now()
);
insert into public.settings default values on conflict do nothing;

-- Catégories
create table if not exists public.categories (
  id              uuid primary key default gen_random_uuid(),
  slug            text not null unique,
  name            text not null check (length(name) between 1 and 80),
  subtitle_style  text not null default 'none' check (subtitle_style in ('dash','parentheses','none')),
  sort_order      int not null default 0,
  is_active       boolean not null default true,
  is_archived     boolean not null default false,
  created_at      timestamptz not null default now()
);

-- Candidats (chanson, film, comédien, groupe, artiste...)
-- name     = artiste / nom du film / nom du candidat (affiché sur l'image)
-- subtitle = titre de la chanson / nom du groupe du film
create table if not exists public.candidates (
  id              uuid primary key default gen_random_uuid(),
  category_id     uuid not null references public.categories(id) on delete restrict,
  name            text not null check (length(name) between 1 and 120),
  subtitle        text check (subtitle is null or length(subtitle) <= 120),
  description     text check (description is null or length(description) <= 1000),
  image_url       text,
  external_url    text check (external_url is null or external_url ~* '^https?://'),
  is_published    boolean not null default false,
  sort_order      int not null default 0,
  created_at      timestamptz not null default now(),
  updated_at      timestamptz not null default now(),
  unique (id, category_id)
);
create index if not exists candidates_category_idx on public.candidates(category_id);

-- Bulletins : UN SEUL par appareil et par semaine (garanti par la base)
create table if not exists public.ballots (
  id          uuid primary key default gen_random_uuid(),
  device_id   text not null check (length(device_id) between 16 and 100),
  week_start  date not null,
  ip_hash     text,
  created_at  timestamptz not null default now(),
  unique (device_id, week_start)
);

-- Votes : jamais modifiés, jamais supprimés
create table if not exists public.votes (
  id           bigint generated always as identity primary key,
  ballot_id    uuid not null references public.ballots(id) on delete restrict,
  candidate_id uuid not null,
  category_id  uuid not null references public.categories(id) on delete restrict,
  week_start   date not null,
  month_start  date not null,
  year_start   date not null,
  created_at   timestamptz not null default now(),
  unique (ballot_id, category_id),  -- un seul candidat par catégorie et par bulletin
  foreign key (candidate_id, category_id)
    references public.candidates(id, category_id) on delete restrict
);
create index if not exists votes_week_idx  on public.votes(week_start,  category_id, candidate_id);
create index if not exists votes_month_idx on public.votes(month_start, category_id, candidate_id);
create index if not exists votes_year_idx  on public.votes(year_start,  category_id, candidate_id);

-- Gagnants (calculés automatiquement, gardés pour toujours)
-- Affichés en haut de la catégorie de period_end jusqu'à visible_until (24 h)
create table if not exists public.winners (
  id            uuid primary key default gen_random_uuid(),
  period_type   text not null check (period_type in ('week','month','year')),
  period_start  date not null,
  category_id   uuid not null references public.categories(id) on delete restrict,
  candidate_id  uuid not null references public.candidates(id) on delete restrict,
  vote_count    int not null,
  total_votes   int not null,
  period_end    timestamptz not null,
  visible_until timestamptz not null,
  published_at  timestamptz not null default now(),
  unique (period_type, period_start, category_id)
);

-- Messages visiteur <-> administrateur
create table if not exists public.conversations (
  id               uuid primary key default gen_random_uuid(),
  visitor_key      text not null unique check (length(visitor_key) between 16 and 100),
  created_at       timestamptz not null default now(),
  last_message_at  timestamptz not null default now()
);
create table if not exists public.messages (
  id               bigint generated always as identity primary key,
  conversation_id  uuid not null references public.conversations(id) on delete cascade,
  sender           text not null check (sender in ('visitor','admin')),
  body             text not null check (length(body) between 1 and 1000),
  is_read          boolean not null default false,
  created_at       timestamptz not null default now()
);
create index if not exists messages_conv_idx on public.messages(conversation_id, created_at);

-- Administrateur (liés à un compte Supabase Auth)
create table if not exists public.admins (
  user_id uuid primary key references auth.users(id) on delete cascade
);

create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as
$$ select exists (select 1 from public.admins where user_id = auth.uid()) $$;

-- ---------------------------------------------------------------------
-- 3. DÉCLENCHEURS (périodes automatiques + historique protégé)
-- ---------------------------------------------------------------------
create or replace function public.trg_ballots_set_week() returns trigger
language plpgsql as $$
begin
  new.week_start := public.bj_week_start(new.created_at);
  return new;
end $$;
drop trigger if exists ballots_set_week on public.ballots;
create trigger ballots_set_week before insert on public.ballots
  for each row execute function public.trg_ballots_set_week();

create or replace function public.trg_votes_set_periods() returns trigger
language plpgsql as $$
begin
  select b.created_at into new.created_at from public.ballots b where b.id = new.ballot_id;
  if new.created_at is null then raise exception 'Bulletin introuvable'; end if;
  new.week_start  := public.bj_week_start(new.created_at);
  new.month_start := public.bj_month_start(new.created_at);
  new.year_start  := public.bj_year_start(new.created_at);
  return new;
end $$;
drop trigger if exists votes_set_periods on public.votes;
create trigger votes_set_periods before insert on public.votes
  for each row execute function public.trg_votes_set_periods();

create or replace function public.trg_forbid_change() returns trigger
language plpgsql as $$
begin
  raise exception 'Lecture seule : l''historique des votes ne peut pas etre modifie';
end $$;

drop trigger if exists votes_readonly on public.votes;
create trigger votes_readonly before update or delete on public.votes
  for each row execute function public.trg_forbid_change();
drop trigger if exists votes_no_truncate on public.votes;
create trigger votes_no_truncate before truncate on public.votes
  for each statement execute function public.trg_forbid_change();

drop trigger if exists ballots_readonly on public.ballots;
create trigger ballots_readonly before update or delete on public.ballots
  for each row execute function public.trg_forbid_change();
drop trigger if exists ballots_no_truncate on public.ballots;
create trigger ballots_no_truncate before truncate on public.ballots
  for each statement execute function public.trg_forbid_change();

-- ---------------------------------------------------------------------
-- 4. CALCUL DES RÉSULTATS (semaine / mois / année, même règle partout)
--    Égalité : gagne celui dont le dernier vote est arrivé en premier
--    (« premier arrivé, premier servi »).
-- ---------------------------------------------------------------------
create or replace function public.compute_results(p_period text, p_start date)
returns table (category_id uuid, candidate_id uuid, votes bigint, total bigint, percent numeric, rank int)
language sql stable security definer set search_path = public as
$$
  with tally as (
    select v.candidate_id as cid, count(*) as n, max(v.created_at) as last_vote
    from public.votes v
    where (p_period = 'week'  and v.week_start  = p_start)
       or (p_period = 'month' and v.month_start = p_start)
       or (p_period = 'year'  and v.year_start  = p_start)
    group by v.candidate_id
  ), base as (
    select c.category_id as catid, c.id as cid, c.name as cname,
           coalesce(t.n, 0) as n, t.last_vote
    from public.candidates c
    left join tally t on t.cid = c.id
    where c.is_published or t.n is not null
  )
  select b.catid, b.cid, b.n,
         sum(b.n) over (partition by b.catid),
         case when sum(b.n) over (partition by b.catid) = 0 then 0
              else round(b.n * 100.0 / sum(b.n) over (partition by b.catid), 1) end,
         (row_number() over (partition by b.catid
                             order by b.n desc, b.last_vote asc nulls last, b.cname))::int
  from base b
$$;

-- Version publique : respecte les réglages « afficher / masquer »
create or replace function public.public_results(p_period text, p_start date default null)
returns table (category_id uuid, candidate_id uuid, votes bigint, percent numeric, rank int)
language plpgsql stable security definer set search_path = public as
$$
declare
  s      date;
  show_c boolean;
  show_r boolean;
begin
  if p_period not in ('week','month','year') then
    raise exception 'Periode invalide';
  end if;
  select st.show_counters, st.show_rankings into show_c, show_r
  from public.settings st where st.id = 1;
  s := coalesce(p_start, case p_period
        when 'week'  then public.bj_week_start(now())
        when 'month' then public.bj_month_start(now())
        else public.bj_year_start(now()) end);
  return query
    select r.category_id, r.candidate_id,
           case when show_c then r.votes   end,
           case when show_c then r.percent end,
           case when show_r then r.rank    end
    from public.compute_results(p_period, s) r;
end $$;

-- Version administrateur : toutes les données, toujours
create or replace function public.admin_results(p_period text, p_start date default null)
returns table (category_id uuid, candidate_id uuid, votes bigint, total bigint, percent numeric, rank int)
language plpgsql stable security definer set search_path = public as
$$
declare s date;
begin
  if not public.is_admin() then raise exception 'Acces refuse'; end if;
  if p_period not in ('week','month','year') then raise exception 'Periode invalide'; end if;
  s := coalesce(p_start, case p_period
        when 'week'  then public.bj_week_start(now())
        when 'month' then public.bj_month_start(now())
        else public.bj_year_start(now()) end);
  return query select * from public.compute_results(p_period, s);
end $$;

-- ---------------------------------------------------------------------
-- 5. GAGNANTS AUTOMATIQUES
-- ---------------------------------------------------------------------
create or replace function public.compute_winners(p_period text, p_start date) returns int
language plpgsql security definer set search_path = public as
$$
declare
  n int;
  e timestamptz;
begin
  e := public.bj_period_end(p_period, p_start);
  insert into public.winners
    (period_type, period_start, category_id, candidate_id, vote_count, total_votes, period_end, visible_until)
  select p_period, p_start, r.category_id, r.candidate_id, r.votes, r.total, e, e + interval '24 hours'
  from public.compute_results(p_period, p_start) r
  where r.rank = 1 and r.votes > 0 and e <= now()
  on conflict (period_type, period_start, category_id) do nothing;
  get diagnostics n = row_count;
  return n;
end $$;

-- Rattrape toute période terminée qui n'a pas encore de gagnant
create or replace function public.run_scheduled_winners() returns void
language plpgsql security definer set search_path = public as
$$
declare d date;
begin
  for d in select distinct v.week_start from public.votes v
           where v.week_start < public.bj_week_start(now())
             and not exists (select 1 from public.winners w
                             where w.period_type = 'week' and w.period_start = v.week_start)
  loop perform public.compute_winners('week', d); end loop;

  for d in select distinct v.month_start from public.votes v
           where v.month_start < public.bj_month_start(now())
             and not exists (select 1 from public.winners w
                             where w.period_type = 'month' and w.period_start = v.month_start)
  loop perform public.compute_winners('month', d); end loop;

  for d in select distinct v.year_start from public.votes v
           where v.year_start < public.bj_year_start(now())
             and not exists (select 1 from public.winners w
                             where w.period_type = 'year' and w.period_start = v.year_start)
  loop perform public.compute_winners('year', d); end loop;
end $$;

-- Suppression d'une catégorie : archivée si elle a un historique, sinon supprimée
create or replace function public.admin_delete_category(p_id uuid) returns text
language plpgsql security definer set search_path = public as
$$
begin
  if not public.is_admin() then raise exception 'Acces refuse'; end if;
  if exists (select 1 from public.votes   where category_id = p_id)
  or exists (select 1 from public.winners where category_id = p_id) then
    update public.categories set is_archived = true, is_active = false where id = p_id;
    return 'archived';
  end if;
  delete from public.candidates where category_id = p_id;
  delete from public.categories where id = p_id;
  return 'deleted';
end $$;

-- ---------------------------------------------------------------------
-- 6. SÉCURITÉ : RLS + DROITS EXPLICITES
--    Les visiteurs ne peuvent ni écrire de votes ni lire les votes bruts.
--    Les votes passeront uniquement par la fonction serveur (étape 3).
-- ---------------------------------------------------------------------
alter table public.settings      enable row level security;
alter table public.categories    enable row level security;
alter table public.candidates    enable row level security;
alter table public.ballots       enable row level security;
alter table public.votes         enable row level security;
alter table public.winners       enable row level security;
alter table public.conversations enable row level security;
alter table public.messages      enable row level security;
alter table public.admins        enable row level security;

drop policy if exists settings_read on public.settings;
create policy settings_read on public.settings for select using (true);
drop policy if exists settings_admin on public.settings;
create policy settings_admin on public.settings for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists categories_read on public.categories;
create policy categories_read on public.categories for select
  using (is_active and not is_archived);
drop policy if exists categories_admin on public.categories;
create policy categories_admin on public.categories for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists candidates_read on public.candidates;
create policy candidates_read on public.candidates for select using (is_published);
drop policy if exists candidates_admin on public.candidates;
create policy candidates_admin on public.candidates for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists winners_read on public.winners;
create policy winners_read on public.winners for select using (true);

drop policy if exists ballots_admin_read on public.ballots;
create policy ballots_admin_read on public.ballots for select to authenticated
  using (public.is_admin());
drop policy if exists votes_admin_read on public.votes;
create policy votes_admin_read on public.votes for select to authenticated
  using (public.is_admin());

drop policy if exists conv_admin on public.conversations;
create policy conv_admin on public.conversations for all to authenticated
  using (public.is_admin()) with check (public.is_admin());
drop policy if exists msg_admin_read on public.messages;
create policy msg_admin_read on public.messages for select to authenticated
  using (public.is_admin());
drop policy if exists msg_admin_insert on public.messages;
create policy msg_admin_insert on public.messages for insert to authenticated
  with check (public.is_admin());
drop policy if exists msg_admin_update on public.messages;
create policy msg_admin_update on public.messages for update to authenticated
  using (public.is_admin()) with check (public.is_admin());

-- Droits explicites (obligatoires pour l'API Supabase)
grant usage on schema public to anon, authenticated;

grant select on public.settings, public.categories, public.candidates, public.winners to anon;
grant select on public.settings, public.categories, public.candidates, public.winners,
                public.ballots, public.votes, public.conversations, public.messages to authenticated;
grant update on public.settings to authenticated;
grant insert, update, delete on public.categories, public.candidates to authenticated;
grant insert, update on public.conversations to authenticated;
grant insert, update on public.messages to authenticated;
grant usage, select on all sequences in schema public to authenticated;

-- Fonctions : fermées par défaut, ouvertes seulement si nécessaire
revoke all on function public.compute_results(text, date)        from public, anon, authenticated;
revoke all on function public.compute_winners(text, date)        from public, anon, authenticated;
revoke all on function public.run_scheduled_winners()            from public, anon, authenticated;
revoke all on function public.public_results(text, date)         from public, anon, authenticated;
revoke all on function public.admin_results(text, date)          from public, anon, authenticated;
revoke all on function public.admin_delete_category(uuid)        from public, anon, authenticated;
revoke all on function public.is_admin()                         from public, anon, authenticated;
grant execute on function public.public_results(text, date)      to anon, authenticated;
grant execute on function public.admin_results(text, date)       to authenticated;
grant execute on function public.admin_delete_category(uuid)     to authenticated;
grant execute on function public.is_admin()                      to authenticated;

-- ---------------------------------------------------------------------
-- 7. PHOTOS (stockage public en lecture, écriture réservée à l'admin)
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('photos', 'photos', true, 2097152, array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;

drop policy if exists photos_public_read on storage.objects;
create policy photos_public_read on storage.objects for select
  using (bucket_id = 'photos');
drop policy if exists photos_admin_insert on storage.objects;
create policy photos_admin_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'photos' and public.is_admin());
drop policy if exists photos_admin_update on storage.objects;
create policy photos_admin_update on storage.objects for update to authenticated
  using (bucket_id = 'photos' and public.is_admin());
drop policy if exists photos_admin_delete on storage.objects;
create policy photos_admin_delete on storage.objects for delete to authenticated
  using (bucket_id = 'photos' and public.is_admin());

-- ---------------------------------------------------------------------
-- 8. CATÉGORIES DE DÉPART
-- ---------------------------------------------------------------------
insert into public.categories (slug, name, subtitle_style, sort_order) values
  ('chanson',            'Meilleure chanson',            'dash',        1),
  ('film',               'Meilleur film',                'parentheses', 2),
  ('groupe-danse',       'Meilleur groupe de danse',     'none',        3),
  ('groupe-sapologie',   'Meilleur groupe de sapologie', 'none',        4),
  ('comedien',           'Meilleur comédien',            'none',        5),
  ('artiste-masculin',   'Meilleur artiste masculin',    'none',        6),
  ('artiste-feminine',   'Meilleure artiste féminine',   'none',        7)
on conflict (slug) do nothing;

-- ---------------------------------------------------------------------
-- 9. TÂCHE AUTOMATIQUE (toutes les heures, à la minute 5)
--    Si cette ligne échoue : Database > Extensions > activer « pg_cron »,
--    puis relancer uniquement les 2 lignes ci-dessous.
-- ---------------------------------------------------------------------
create extension if not exists pg_cron;
select cron.schedule('limbapp-winners', '5 * * * *', $$select public.run_scheduled_winners()$$);

-- ---------------------------------------------------------------------
-- 10. APRÈS AVOIR CRÉÉ VOTRE COMPTE ADMIN (Authentication > Users > Add user),
--     décommentez, mettez votre e-mail, puis lancez :
-- ---------------------------------------------------------------------
-- insert into public.admins (user_id)
-- select id from auth.users where email = 'VOTRE-EMAIL@exemple.com';

-- =====================================================================
-- PARTIE B : fonctions de vote et de messages
-- (appelées uniquement par les fonctions serveur vote et chat)
-- =====================================================================

create index if not exists ballots_ip_idx on public.ballots(ip_hash, created_at);
alter table public.conversations add column if not exists ip_hash text;
create index if not exists conversations_ip_idx on public.conversations(ip_hash, created_at);

-- ---------------------------------------------------------------------
-- VOTE : tout ou rien. Un bulletin par appareil et par semaine.
-- Résultat : {ok:true} ou {ok:false, reason:'already_voted'|'rate_limited'|'invalid'|'invalid_choice'}
-- ---------------------------------------------------------------------
create or replace function public.cast_vote(p_device text, p_ip_hash text, p_choices jsonb)
returns jsonb
language plpgsql security definer set search_path = public as
$$
declare
  v_ballot uuid;
  k text; v text;
  max_per_ip_hour constant int := 40;   -- plusieurs personnes peuvent partager une même IP mobile
begin
  if p_device is null or length(p_device) not between 16 and 100
     or p_choices is null or jsonb_typeof(p_choices) <> 'object' or p_choices = '{}'::jsonb then
    return jsonb_build_object('ok', false, 'reason', 'invalid');
  end if;

  if p_ip_hash is not null and
     (select count(*) from public.ballots b
       where b.ip_hash = p_ip_hash and b.created_at > now() - interval '1 hour') >= max_per_ip_hour then
    return jsonb_build_object('ok', false, 'reason', 'rate_limited');
  end if;

  -- Toutes les sélections doivent être valides : candidat publié, de la bonne catégorie, catégorie active
  for k, v in select e.key, e.value #>> '{}' from jsonb_each(p_choices) e loop
    if not exists (
      select 1 from public.candidates c
      join public.categories ca on ca.id = c.category_id
      where c.id = v::uuid and c.category_id = k::uuid
        and c.is_published and ca.is_active and not ca.is_archived) then
      return jsonb_build_object('ok', false, 'reason', 'invalid_choice');
    end if;
  end loop;

  begin
    insert into public.ballots (device_id, ip_hash) values (p_device, p_ip_hash) returning id into v_ballot;
  exception when unique_violation then
    return jsonb_build_object('ok', false, 'reason', 'already_voted');
  end;

  insert into public.votes (ballot_id, candidate_id, category_id)
  select v_ballot, (e.value #>> '{}')::uuid, e.key::uuid from jsonb_each(p_choices) e;

  return jsonb_build_object('ok', true);
exception when invalid_text_representation then
  return jsonb_build_object('ok', false, 'reason', 'invalid');
end $$;

-- ---------------------------------------------------------------------
-- MESSAGES
-- ---------------------------------------------------------------------
create or replace function public.chat_list(p_key text) returns jsonb
language plpgsql security definer set search_path = public as
$$
declare c uuid;
begin
  if p_key is null or length(p_key) not between 16 and 100 then return '[]'::jsonb; end if;
  select id into c from public.conversations where visitor_key = p_key;
  if c is null then return '[]'::jsonb; end if;
  return coalesce((
    select jsonb_agg(jsonb_build_object('sender', t.sender, 'body', t.body, 'created_at', t.created_at) order by t.created_at)
    from (select m.sender, m.body, m.created_at from public.messages m
          where m.conversation_id = c order by m.created_at desc limit 200) t
  ), '[]'::jsonb);
end $$;

create or replace function public.chat_send(p_key text, p_ip_hash text, p_body text) returns jsonb
language plpgsql security definer set search_path = public as
$$
declare c uuid; body text := btrim(coalesce(p_body, ''));
begin
  if p_key is null or length(p_key) not between 16 and 100 or length(body) not between 1 and 1000 then
    return jsonb_build_object('ok', false, 'reason', 'invalid');
  end if;
  select id into c from public.conversations where visitor_key = p_key;
  if c is null then
    if p_ip_hash is not null and (select count(*) from public.conversations
         where ip_hash = p_ip_hash and created_at > now() - interval '1 hour') >= 5 then
      return jsonb_build_object('ok', false, 'reason', 'rate_limited');
    end if;
    insert into public.conversations (visitor_key, ip_hash) values (p_key, p_ip_hash) returning id into c;
  end if;
  if (select count(*) from public.messages
       where conversation_id = c and sender = 'visitor' and created_at > now() - interval '1 hour') >= 10 then
    return jsonb_build_object('ok', false, 'reason', 'rate_limited');
  end if;
  insert into public.messages (conversation_id, sender, body) values (c, 'visitor', body);
  update public.conversations set last_message_at = now() where id = c;
  return jsonb_build_object('ok', true);
end $$;

-- Droits : seule la clé service_role (fonctions serveur) peut les appeler
revoke all on function public.cast_vote(text, text, jsonb)  from public, anon, authenticated;
revoke all on function public.chat_list(text)               from public, anon, authenticated;
revoke all on function public.chat_send(text, text, text)   from public, anon, authenticated;
grant execute on function public.cast_vote(text, text, jsonb) to service_role;
grant execute on function public.chat_list(text)              to service_role;
grant execute on function public.chat_send(text, text, text)  to service_role;
