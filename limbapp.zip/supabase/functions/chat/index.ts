// Fonction serveur « chat » : messages entre un visiteur anonyme et l'administrateur.
// À déployer SANS vérification JWT (visiteurs anonymes).
import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const cors = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });
const sha = async (t: string) =>
  [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t)))]
    .map((x) => x.toString(16).padStart(2, "0")).join("");

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ message: "Méthode non autorisée." }, 405);

  let body: any;
  try { body = await req.json(); } catch { return json({ message: "Requête invalide." }, 400); }
  const key = String(body.key ?? "");
  if (key.length < 16 || key.length > 100) return json({ message: "Requête invalide." }, 400);

  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });

  if (body.action === "list") {
    const { data, error } = await sb.rpc("chat_list", { p_key: key });
    if (error) return json({ message: "Erreur du serveur." }, 500);
    return json({ messages: data });
  }

  if (body.action === "send") {
    const ip = (req.headers.get("cf-connecting-ip") ?? req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim();
    const { data, error } = await sb.rpc("chat_send", {
      p_key: key,
      p_ip_hash: ip ? await sha(ip + (Deno.env.get("IP_SALT") ?? "")) : null,
      p_body: String(body.body ?? ""),
    });
    if (error) return json({ message: "Erreur du serveur." }, 500);
    if (data?.ok) return json({ ok: true });
    return json({ message: data?.reason === "rate_limited" ? "Trop de messages. Réessayez plus tard." : "Message invalide." }, data?.reason === "rate_limited" ? 429 : 400);
  }
  return json({ message: "Action inconnue." }, 400);
});
