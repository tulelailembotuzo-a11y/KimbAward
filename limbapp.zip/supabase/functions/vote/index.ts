// Fonction serveur « vote » : vérifie l'anti-robot, limite les abus, puis enregistre le bulletin.
// À déployer SANS vérification JWT (les visiteurs sont anonymes) : le contrôle se fait ici.
import { createClient } from "npm:@supabase/supabase-js@2.45.4";

const cors = {
  "Access-Control-Allow-Origin": Deno.env.get("ALLOWED_ORIGIN") ?? "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};
const json = (b: unknown, s = 200) =>
  new Response(JSON.stringify(b), { status: s, headers: { ...cors, "Content-Type": "application/json" } });
const sha = async (t: string) =>
  [...new Uint8Array(await crypto.subtle.digest("SHA-256", new TextEncoder().encode(t)))]
    .map((x) => x.toString(16).padStart(2, "0")).join("");

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") return new Response("ok", { headers: cors });
  if (req.method !== "POST") return json({ ok: false, message: "Méthode non autorisée." }, 405);

  let body: any;
  try { body = await req.json(); } catch { return json({ ok: false, message: "Requête invalide." }, 400); }

  const device = String(body.device_id ?? "");
  const choices = body.choices;
  if (device.length < 16 || device.length > 100 || !choices || typeof choices !== "object" ||
      Array.isArray(choices) || Object.keys(choices).length === 0 || Object.keys(choices).length > 50) {
    return json({ ok: false, message: "Bulletin invalide." }, 400);
  }

  const ip = (req.headers.get("cf-connecting-ip") ?? req.headers.get("x-forwarded-for") ?? "").split(",")[0].trim();

  // Anti-robot Cloudflare Turnstile (actif seulement si le secret est défini)
  const secret = Deno.env.get("TURNSTILE_SECRET");
  if (secret) {
    const f = new URLSearchParams({ secret, response: String(body.token ?? "") });
    if (ip) f.set("remoteip", ip);
    const r = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", { method: "POST", body: f });
    const j = await r.json().catch(() => ({}));
    if (!j.success) return json({ ok: false, message: "Vérification anti-robot échouée. Réessayez." }, 403);
  }

  const sb = createClient(Deno.env.get("SUPABASE_URL")!, Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!, { auth: { persistSession: false } });
  const { data, error } = await sb.rpc("cast_vote", {
    p_device: device,
    p_ip_hash: ip ? await sha(ip + (Deno.env.get("IP_SALT") ?? "")) : null,
    p_choices: choices,
  });
  if (error) return json({ ok: false, message: "Erreur du serveur. Réessayez plus tard." }, 500);
  if (data?.ok) return json({ ok: true });

  const msg: Record<string, [string, number]> = {
    already_voted: ["Cet appareil a déjà voté cette semaine. Vous pourrez voter à nouveau lundi à 00 h 00.", 409],
    rate_limited: ["Trop de votes depuis cette connexion. Réessayez dans une heure.", 429],
    invalid_choice: ["Un candidat choisi n'est plus disponible. Rechargez la page.", 400],
    invalid: ["Bulletin invalide.", 400],
  };
  const [message, status] = msg[data?.reason] ?? ["Vote refusé.", 400];
  return json({ ok: false, message }, status);
});
