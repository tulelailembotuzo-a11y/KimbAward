(() => {
'use strict';
const C = window.LIMB || {};
const $ = s => document.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
const B = C.SUPABASE_URL;
let token = null; try { token = sessionStorage.getItem('limb_admin'); } catch (e) {}
let cats = [], cands = [], ui = { tab: 'cands', cat: null, conv: null }, editing = null;

// --- Accès (jeton de l'administrateur, jamais de clé secrète) ---
const hdr = x => ({ apikey: C.SUPABASE_ANON_KEY, Authorization: 'Bearer ' + (token || C.SUPABASE_ANON_KEY), 'Content-Type': 'application/json', ...(x || {}) });
async function api(path, o) {
  const r = await fetch(B + path, { ...(o || {}), headers: hdr((o || {}).headers) });
  if (r.status === 401) { logout(); throw new Error('Session expirée. Reconnectez-vous.'); }
  if (!r.ok) { let t = ''; try { t = (await r.json()).message || ''; } catch (e) {} throw new Error(t || 'Erreur ' + r.status); }
  return (r.headers.get('content-type') || '').includes('json') ? r.json() : null;
}
const rest = (p, o) => api('/rest/v1/' + p, o);
const rpc = (n, b) => rest('rpc/' + n, { method: 'POST', body: JSON.stringify(b || {}) });
const send = (m, p, b) => rest(p, { method: m, body: JSON.stringify(b), headers: { Prefer: 'return=minimal' } });
const say = (t, k) => { const m = $('#amsg'); m.textContent = t || ''; m.className = 'msg ' + (k || ''); };
const guard = f => async (...a) => { try { await f(...a); } catch (e) { say(e.message, 'err'); } };

// --- Connexion : le nom + les 2 mots de passe sont vérifiés par Supabase ---
function logout() { token = null; try { sessionStorage.removeItem('limb_admin'); } catch (e) {} $('#app-view').hidden = true; $('#login-view').hidden = false; }
$('#login').addEventListener('submit', async e => {
  e.preventDefault();
  const err = t => { $('#lmsg').textContent = t; };
  err('');
  if ($('#u').value.trim().toLowerCase() !== String(C.ADMIN_NAME || 'LimbApp Admin').toLowerCase()) return err('Identifiants incorrects.');
  try {
    const r = await fetch(B + '/auth/v1/token?grant_type=password', { method: 'POST', headers: { apikey: C.SUPABASE_ANON_KEY, 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: C.ADMIN_EMAIL, password: $('#p1').value + '|' + $('#p2').value }) });
    if (!r.ok) return err('Identifiants incorrects.');
    token = (await r.json()).access_token;
    if (!(await rpc('is_admin'))) { logout(); return err('Accès refusé.'); }
    try { sessionStorage.setItem('limb_admin', token); } catch (x) {}
    $('#p1').value = ''; $('#p2').value = '';
    start();
  } catch (x) { err('Connexion impossible.'); }
});
$('#logout').addEventListener('click', logout);

async function start() {
  $('#login-view').hidden = true; $('#app-view').hidden = false;
  await reload(); go(ui.tab);
}
async function reload() {
  [cats, cands] = await Promise.all([rest('categories?select=*&order=sort_order.asc,created_at.asc'), rest('candidates?select=*&order=created_at.desc')]);
  if (!ui.cat && cats[0]) ui.cat = cats[0].id;
}
const go = guard(async t => {
  ui.tab = t; say('');
  document.querySelectorAll('#atabs .tab').forEach(b => b.classList.toggle('on', b.dataset.t === t));
  await ({ cands: vCands, cats: vCats, settings: vSettings, data: vData, msgs: vMsgs })[t]();
});
$('#atabs').addEventListener('click', e => { const b = e.target.closest('.tab'); if (b) go(b.dataset.t); });
document.addEventListener('click', e => { if (e.target.closest('[data-close]') || e.target.classList.contains('modal')) $('#fm').hidden = true; });

// --- Candidats ---
function vCands() {
  const list = cands.filter(c => c.category_id === ui.cat);
  $('#view').innerHTML = '<div class="card"><div class="row2"><select id="fc">' + cats.map(c => '<option value="' + c.id + '"' + (c.id === ui.cat ? ' selected' : '') + '>' + esc(c.name) + (c.is_active ? '' : ' (masquée)') + '</option>').join('') +
    '</select><button class="btn" id="add" style="margin:0">+ Ajouter un candidat</button></div><p class="muted">' + list.length + ' candidat(s), ' + list.filter(c => c.is_published).length + ' publié(s)</p>' +
    list.map(c => '<div class="ar" data-id="' + c.id + '">' + (c.image_url ? '<img src="' + esc(c.image_url) + '" alt="">' : '<div class="im" style="width:42px;height:42px;border-radius:6px"><span class="ph" style="font-size:18px">' + esc(c.name.charAt(0)) + '</span></div>') +
      '<div class="nm"><b>' + esc(c.name) + '</b> <span class="muted">' + esc(c.subtitle || '') + '</span></div>' +
      '<button data-a="pub">' + (c.is_published ? 'Masquer' : 'Publier') + '</button><button data-a="edit">Modifier</button><button data-a="del">Supprimer</button></div>').join('') + '</div>';
  $('#fc').onchange = e => { ui.cat = e.target.value; vCands(); };
  $('#add').onclick = () => openForm(null);
  $('#view').querySelectorAll('.ar').forEach(row => row.addEventListener('click', guard(async e => {
    const a = e.target.dataset.a; if (!a) return;
    const c = cands.find(x => x.id === row.dataset.id);
    if (a === 'edit') return openForm(c);
    if (a === 'pub') { await send('PATCH', 'candidates?id=eq.' + c.id, { is_published: !c.is_published, updated_at: new Date().toISOString() }); }
    if (a === 'del') {
      if (!confirm('Supprimer « ' + c.name + ' » ? S\'il a déjà des votes, la suppression sera refusée : masquez-le plutôt.')) return;
      await send('DELETE', 'candidates?id=eq.' + c.id);
    }
    await reload(); vCands();
  })));
}
function openForm(c) {
  editing = c;
  $('#ftitle').textContent = c ? 'Modifier le candidat' : 'Nouveau candidat';
  $('#f-cat').innerHTML = cats.map(k => '<option value="' + k.id + '">' + esc(k.name) + '</option>').join('');
  $('#f-cat').value = c ? c.category_id : ui.cat;
  $('#f-name').value = c ? c.name : ''; $('#f-sub').value = c ? c.subtitle || '' : '';
  $('#f-desc').value = c ? c.description || '' : ''; $('#f-url').value = c ? c.external_url || '' : '';
  $('#f-img').value = ''; $('#f-pub').checked = c ? c.is_published : true; $('#fmsg').textContent = '';
  $('#fm').hidden = false;
}
async function shrink(file) {
  const bmp = await createImageBitmap(file), k = Math.min(1, 900 / Math.max(bmp.width, bmp.height));
  const cv = document.createElement('canvas'); cv.width = Math.round(bmp.width * k); cv.height = Math.round(bmp.height * k);
  cv.getContext('2d').drawImage(bmp, 0, 0, cv.width, cv.height);
  return new Promise(r => cv.toBlob(r, 'image/jpeg', 0.82));
}
async function upload(file) {
  const name = (crypto.randomUUID ? crypto.randomUUID() : Date.now() + '' + Math.random().toString(36).slice(2)) + '.jpg';
  const r = await fetch(B + '/storage/v1/object/photos/' + name, { method: 'POST', headers: { apikey: C.SUPABASE_ANON_KEY, Authorization: 'Bearer ' + token, 'Content-Type': 'image/jpeg' }, body: await shrink(file) });
  if (!r.ok) throw new Error('Envoi de la photo impossible.');
  return B + '/storage/v1/object/public/photos/' + name;
}
$('#f-save').addEventListener('click', async () => {
  const m = $('#fmsg'), btn = $('#f-save'); m.className = 'msg err';
  const name = $('#f-name').value.trim(), url = $('#f-url').value.trim();
  if (!name) { m.textContent = 'Le nom est obligatoire.'; return; }
  if (url && !/^https?:\/\//i.test(url)) { m.textContent = 'Le lien doit commencer par http:// ou https://'; return; }
  btn.disabled = true; m.className = 'msg'; m.textContent = 'Enregistrement…';
  try {
    const body = { category_id: $('#f-cat').value, name, subtitle: $('#f-sub').value.trim() || null, description: $('#f-desc').value.trim() || null, external_url: url || null, is_published: $('#f-pub').checked, updated_at: new Date().toISOString() };
    const f = $('#f-img').files[0]; if (f) body.image_url = await upload(f);
    if (editing) await send('PATCH', 'candidates?id=eq.' + editing.id, body); else await send('POST', 'candidates', body);
    ui.cat = body.category_id; $('#fm').hidden = true; await reload(); vCands();
  } catch (e) { m.className = 'msg err'; m.textContent = e.message; }
  btn.disabled = false;
});

// --- Catégories ---
function vCats() {
  $('#view').innerHTML = '<div class="card"><h3 style="margin-top:0;color:#F5B800">Nouvelle catégorie</h3><div class="row2"><input id="cn" placeholder="Ex. Meilleur clip" maxlength="80">' +
    '<select id="cs"><option value="none">Nom seul (comédien, groupe…)</option><option value="dash">Nom — Titre (chanson)</option><option value="parentheses">Nom (Groupe) (film)</option></select></div>' +
    '<button class="btn" id="cadd">Ajouter la catégorie</button></div><div class="card">' +
    cats.map(c => '<div class="ar" data-id="' + c.id + '"><div class="nm"><b>' + esc(c.name) + '</b> <span class="muted">' + (c.is_archived ? 'archivée' : c.is_active ? '' : 'masquée') + '</span></div>' +
      '<button data-a="ren">Renommer</button><button data-a="act">' + (c.is_active ? 'Masquer' : 'Afficher') + '</button><button data-a="del">Supprimer</button></div>').join('') + '</div>';
  $('#cadd').onclick = guard(async () => {
    const name = $('#cn').value.trim(); if (!name) throw new Error('Entrez un nom.');
    const slug = name.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') + '-' + Math.random().toString(36).slice(2, 6);
    await send('POST', 'categories', { name, slug, subtitle_style: $('#cs').value, sort_order: cats.reduce((m, c) => Math.max(m, c.sort_order), 0) + 1 });
    await reload(); vCats(); say('Catégorie ajoutée.', 'ok');
  });
  $('#view').querySelectorAll('.ar').forEach(row => row.addEventListener('click', guard(async e => {
    const a = e.target.dataset.a; if (!a) return;
    const c = cats.find(x => x.id === row.dataset.id);
    if (a === 'ren') { const n = prompt('Nouveau nom :', c.name); if (!n || !n.trim()) return; await send('PATCH', 'categories?id=eq.' + c.id, { name: n.trim() }); }
    if (a === 'act') await send('PATCH', 'categories?id=eq.' + c.id, { is_active: !c.is_active, is_archived: false });
    if (a === 'del') {
      if (!confirm('Supprimer « ' + c.name + ' » ? Si elle a un historique de votes, elle sera archivée (rien n\'est perdu).')) return;
      const r = await rpc('admin_delete_category', { p_id: c.id });
      say(r === 'archived' ? 'Catégorie archivée : l\'historique est conservé.' : 'Catégorie supprimée.', 'ok');
    }
    await reload(); vCats();
  })));
}

// --- Réglages ---
async function vSettings() {
  const s = (await rest('settings?select=*&id=eq.1'))[0] || {};
  $('#view').innerHTML = '<div class="card"><label for="s-wa">Numéro WhatsApp (avec l\'indicatif pays, ex. 25779000000)</label><input id="s-wa" value="' + esc(s.whatsapp) + '">' +
    '<label for="s-em">Adresse e-mail (Gmail)</label><input id="s-em" type="email" value="' + esc(s.email) + '">' +
    '<label class="chk"><input type="checkbox" id="s-c"' + (s.show_counters ? ' checked' : '') + '> Afficher les compteurs de votes aux visiteurs</label>' +
    '<label class="chk"><input type="checkbox" id="s-r"' + (s.show_rankings ? ' checked' : '') + '> Afficher les classements aux visiteurs</label>' +
    '<p class="muted">Masquer ne supprime rien : les votes sont toujours enregistrés et calculés.</p><button class="btn" id="s-save">Enregistrer</button></div>';
  $('#s-save').onclick = guard(async () => {
    await send('PATCH', 'settings?id=eq.1', { whatsapp: $('#s-wa').value.trim(), email: $('#s-em').value.trim(), show_counters: $('#s-c').checked, show_rankings: $('#s-r').checked, updated_at: new Date().toISOString() });
    say('Réglages enregistrés.', 'ok');
  });
}

// --- Base de données : résultats, historique, export CSV ---
const csv = (name, rows) => {
  const t = rows.map(r => r.map(v => '"' + String(v == null ? '' : v).replace(/"/g, '""') + '"').join(',')).join('\n');
  const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob(['\ufeff' + t], { type: 'text/csv' })); a.download = name; a.click();
};
async function vData() {
  $('#view').innerHTML = '<div class="card"><div class="row2"><select id="dp"><option value="week">Semaine</option><option value="month">Mois</option><option value="year">Année</option></select>' +
    '<input id="dd" type="date"></div><p class="muted">Laissez la date vide pour la période en cours. Pour une période passée, choisissez le 1er jour de la période (lundi pour une semaine, le 1er pour un mois ou une année).</p>' +
    '<button class="btn" id="dgo">Afficher</button> <button class="btn alt" id="dcsv" hidden>Exporter en CSV</button></div><div id="dres"></div><div id="dwin"></div>';
  let rows = [];
  const run = guard(async () => {
    const p = $('#dp').value, d = $('#dd').value || null;
    const r = await rpc('admin_results', { p_period: p, p_start: d });
    rows = [['Catégorie', 'Rang', 'Candidat', 'Votes', 'Pourcentage', 'Total catégorie']];
    $('#dres').innerHTML = cats.map(cat => {
      const l = r.filter(x => x.category_id === cat.id).sort((a, b) => a.rank - b.rank);
      l.forEach(x => { const c = cands.find(k => k.id === x.candidate_id); rows.push([cat.name, x.rank, c ? c.name : '', x.votes, x.percent, x.total]); });
      return '<div class="card"><b>' + esc(cat.name) + '</b> <span class="muted">' + (l[0] ? l[0].total : 0) + ' vote(s)</span><div class="tbl-wrap"><table class="tbl"><tr><th>#</th><th>Candidat</th><th>Votes</th><th>%</th></tr>' +
        l.map(x => { const c = cands.find(k => k.id === x.candidate_id); return '<tr><td>' + x.rank + '</td><td>' + esc(c ? c.name : '?') + '</td><td>' + x.votes + '</td><td>' + x.percent + '</td></tr>'; }).join('') + '</table></div></div>';
    }).join('');
    $('#dcsv').hidden = false;
    const w = await rest('winners?select=*,candidates(name),categories(name)&order=period_end.desc&limit=200');
    $('#dwin').innerHTML = '<div class="card"><b>Historique des gagnants</b><div class="tbl-wrap"><table class="tbl"><tr><th>Type</th><th>Période</th><th>Catégorie</th><th>Gagnant</th><th>Votes</th></tr>' +
      w.map(x => '<tr><td>' + ({ week: 'Semaine', month: 'Mois', year: 'Année' })[x.period_type] + '</td><td>' + x.period_start + '</td><td>' + esc(x.categories ? x.categories.name : '') + '</td><td>' + esc(x.candidates ? x.candidates.name : '') + '</td><td>' + x.vote_count + '/' + x.total_votes + '</td></tr>').join('') + '</table></div></div>';
  });
  $('#dgo').onclick = run; $('#dcsv').onclick = () => csv('limbapp-resultats-' + $('#dp').value + '.csv', rows);
  run();
}

// --- Messages ---
async function vMsgs() {
  const convs = await rest('conversations?select=*&order=last_message_at.desc&limit=100');
  const msgs = await rest('messages?select=conversation_id,sender,body,is_read,created_at&order=created_at.desc&limit=500');
  const last = {}, unread = {};
  msgs.forEach(m => { if (!last[m.conversation_id]) last[m.conversation_id] = m; if (m.sender === 'visitor' && !m.is_read) unread[m.conversation_id] = (unread[m.conversation_id] || 0) + 1; });
  const fmt = d => new Date(d).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' });
  let html = '<div class="card convs">' + (convs.length ? convs.map(c => '<button class="cv" data-id="' + c.id + '"><b>Visiteur ' + esc(c.visitor_key.slice(-6)) + '</b>' + (unread[c.id] ? ' <span style="color:#F5B800">(' + unread[c.id] + ' nouveau)</span>' : '') +
    '<br><span class="muted">' + esc(last[c.id] ? last[c.id].body.slice(0, 60) : '') + ' · ' + fmt(c.last_message_at) + '</span></button>').join('') : '<p class="muted">Aucun message.</p>') + '</div>';
  if (ui.conv) {
    const list = (await rest('messages?select=*&conversation_id=eq.' + ui.conv + '&order=created_at.asc')).slice(-200);
    html += '<div class="card"><div class="chat" id="alog">' + list.map(m => '<div class="b ' + (m.sender === 'admin' ? 'v' : 'a') + '">' + esc(m.body) + '<time>' + fmt(m.created_at) + '</time></div>').join('') + '</div>' +
      '<textarea id="areply" rows="3" maxlength="1000" placeholder="Votre réponse"></textarea><button class="btn" id="asend">Répondre</button></div>';
    send('PATCH', 'messages?conversation_id=eq.' + ui.conv + '&sender=eq.visitor&is_read=eq.false', { is_read: true }).catch(() => {});
  }
  $('#view').innerHTML = html;
  const log = $('#alog'); if (log) log.scrollTop = log.scrollHeight;
  $('#view').querySelectorAll('.cv').forEach(b => b.onclick = () => { ui.conv = b.dataset.id; go('msgs'); });
  const sb = $('#asend');
  if (sb) sb.onclick = guard(async () => {
    const t = $('#areply').value.trim(); if (!t) return;
    sb.disabled = true;
    try {
      await send('POST', 'messages', { conversation_id: ui.conv, sender: 'admin', body: t, is_read: true });
      await send('PATCH', 'conversations?id=eq.' + ui.conv, { last_message_at: new Date().toISOString() });
      go('msgs');
    } finally { sb.disabled = false; }
  });
}

if (token) rpc('is_admin').then(ok => ok ? start() : logout()).catch(logout);
})();
