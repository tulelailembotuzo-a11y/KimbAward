(() => {
'use strict';
const C = window.LIMB || {};
const $ = s => document.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
const H = { apikey: C.SUPABASE_ANON_KEY, Authorization: 'Bearer ' + C.SUPABASE_ANON_KEY };
const get = async p => { const r = await fetch(C.SUPABASE_URL + '/rest/v1/' + p, { headers: H }); if (!r.ok) throw new Error(r.status); return r.json(); };
const rpc = async (n, b) => { const r = await fetch(C.SUPABASE_URL + '/rest/v1/rpc/' + n, { method: 'POST', headers: { ...H, 'Content-Type': 'application/json' }, body: JSON.stringify(b) }); if (!r.ok) throw new Error(r.status); return r.json(); };
const NAMES = { week: 'de la semaine', month: 'du mois', year: "de l'année" };
let period = 'week', cats = [], cands = [];

const label = (t, s) => {
  const d = new Date(s + 'T00:00:00Z');
  if (t === 'year') return String(d.getUTCFullYear());
  if (t === 'month') return d.toLocaleDateString('fr-FR', { month: 'long', year: 'numeric', timeZone: 'UTC' });
  return 'Semaine du ' + d.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' });
};

async function show() {
  try {
    const rows = await rpc('public_results', { p_period: period });
    const by = {}; rows.forEach(r => { (by[r.category_id] = by[r.category_id] || []).push(r); });
    $('#live').innerHTML = '<h2 style="color:#F5B800;font-size:18px;margin:0 0 10px">En cours ' + NAMES[period] + '</h2>' + cats.map(cat => {
      const list = (by[cat.id] || []).sort((a, b) => (a.rank || 1e9) - (b.rank || 1e9));
      const body = list.map(r => {
        const c = cands.find(x => x.id === r.candidate_id); if (!c) return '';
        return '<div class="rk"><span>' + (r.rank != null ? r.rank : '') + '</span><span>' + esc(c.name) + (c.subtitle ? ' <span class="muted">' + esc(c.subtitle) + '</span>' : '') + '</span><span>' +
          (r.votes != null ? r.percent + ' % (' + r.votes + ')' : '') + '</span>' + (r.percent != null ? '<div class="bar"><i style="width:' + r.percent + '%"></i></div>' : '') + '</div>';
      }).join('');
      return '<div class="card"><b>' + esc(cat.name) + '</b>' + (body || '<p class="muted">Aucun candidat pour le moment.</p>') + '</div>';
    }).join('');
    const w = await get('winners?select=*,candidates(name,subtitle),categories(name)&period_type=eq.' + period + '&order=period_end.desc&limit=60');
    $('#hist').innerHTML = w.length ? w.map(x => '<div class="card"><b>' + esc(x.categories ? x.categories.name : '') + '</b> : ' + esc(label(period, x.period_start)) +
      '<br>Gagnant : ' + esc(x.candidates ? x.candidates.name : 'candidat retiré') + (x.candidates && x.candidates.subtitle ? ' <span class="muted">' + esc(x.candidates.subtitle) + '</span>' : '') +
      '<br><span class="muted">' + x.vote_count + ' vote(s) sur ' + x.total_votes + '</span></div>').join('') : '<p class="muted">Aucun gagnant pour le moment.</p>';
    $('#note').hidden = true;
  } catch (e) { $('#note').textContent = 'Impossible de charger les résultats.'; $('#note').hidden = false; }
}

$('#tabs').addEventListener('click', e => {
  const b = e.target.closest('.tab'); if (!b) return;
  document.querySelectorAll('.tab').forEach(t => t.classList.toggle('on', t === b));
  period = b.dataset.p; show();
});
(async () => {
  if (!C.SUPABASE_URL) { $('#note').textContent = 'Le site n’est pas encore configuré.'; $('#note').hidden = false; return; }
  try {
    [cats, cands] = await Promise.all([get('categories?select=*&order=sort_order.asc'), get('candidates?select=id,name,subtitle')]);
    show();
  } catch (e) { $('#note').textContent = 'Impossible de charger les résultats.'; $('#note').hidden = false; }
})();
})();
