(() => {
'use strict';
const C = window.LIMB || {};
const $ = s => document.querySelector(s);
const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, m => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[m]));
const H = { apikey: C.SUPABASE_ANON_KEY, Authorization: 'Bearer ' + C.SUPABASE_ANON_KEY };
const JH = { ...H, 'Content-Type': 'application/json' };

// --- Accès à Supabase (clé publique uniquement) ---
const get = async p => { const r = await fetch(C.SUPABASE_URL + '/rest/v1/' + p, { headers: H }); if (!r.ok) throw new Error(r.status); return r.json(); };
const rpc = async (n, b) => { const r = await fetch(C.SUPABASE_URL + '/rest/v1/rpc/' + n, { method: 'POST', headers: JH, body: JSON.stringify(b || {}) }); if (!r.ok) throw new Error(r.status); return r.json(); };
const fn = async (n, b) => { const r = await fetch(C.SUPABASE_URL + '/functions/v1/' + n, { method: 'POST', headers: JH, body: JSON.stringify(b) }); const j = await r.json().catch(() => ({})); return { code: r.status, ...j }; };

// --- Identifiants anonymes persistants (appareil / conversation) ---
const store = { get(k) { try { return localStorage.getItem(k); } catch (e) { return null; } }, set(k, v) { try { localStorage.setItem(k, v); } catch (e) {} } };
const rid = p => p + (crypto.randomUUID ? crypto.randomUUID() : Date.now().toString(36) + Math.random().toString(36).slice(2, 14));
const myId = (k, p) => { let v = store.get(k); if (!v || v.length < 16) { v = rid(p); store.set(k, v); } return v; };

let cats = [], cands = [], res = {}, wins = [], settings = {};
const choices = {};
let timers = [];
const WL = { week: 'GAGNANT de la SEMAINE', month: 'GAGNANT du MOIS', year: "GAGNANT de l'ANNÉE" };

// --- Affichage ---
function weekLabel() {
  const d = new Date(Date.now() + 7200e3); // heure du Burundi (UTC+2)
  const mon = new Date(d.getTime() - ((d.getUTCDay() + 6) % 7) * 864e5);
  const sun = new Date(mon.getTime() + 6 * 864e5);
  const f = x => x.toLocaleDateString('fr-FR', { day: 'numeric', month: 'long', timeZone: 'UTC' });
  return 'Semaine en cours : lundi ' + f(mon) + ' (00 h 00) → dimanche ' + f(sun) + ' (23 h 59)';
}
const sub = (c, cat) => !c.subtitle ? '' : cat.subtitle_style === 'parentheses' ? '(' + esc(c.subtitle) + ')' : cat.subtitle_style === 'dash' ? '— ' + esc(c.subtitle) : esc(c.subtitle);
const pic = c => c.image_url ? '<img src="' + esc(c.image_url) + '" alt="' + esc(c.name) + '" loading="lazy">' : '<div class="ph">' + esc(c.name.charAt(0).toUpperCase()) + '</div>';
const face = c => pic(c) + '<span class="cap">' + esc(c.name) + '</span>';
const winCard = (t, c, cat) => '<div class="win"><div class="tag">' + WL[t] + '</div><div class="im">' + pic(c) + '</div><div class="tx">' + esc(c.name) + (c.subtitle ? '<i>' + sub(c, cat) + '</i>' : '') + '</div></div>';
const pct = c => { const r = res[c.id]; return r && r.votes != null ? r.percent + ' % (' + r.votes + ')' : ''; };

function render() {
  timers.forEach(clearInterval); timers = [];
  const lists = {};
  $('#cats').innerHTML = cats.map(cat => {
    let list = cands.filter(c => c.category_id === cat.id);
    lists[cat.id] = list.slice();
    if (settings.show_rankings) list.sort((a, b) => ((res[a.id] || {}).rank || 1e9) - ((res[b.id] || {}).rank || 1e9));
    const w = ['week', 'month', 'year'].map(t => wins.find(x => x.category_id === cat.id && x.period_type === t)).filter(Boolean)
      .map(x => { const c = cands.find(k => k.id === x.candidate_id); return c ? winCard(x.period_type, c, cat) : ''; }).join('');
    const n = list.length;
    const cube = n ? '<div class="scene"><div class="cube" data-cat="' + cat.id + '">' + [0, 1, 2, 3].map(i => '<div class="face" style="--i:' + i + '">' + face(lists[cat.id][i % n]) + '</div>').join('') + '</div></div>' : '';
    const rows = list.map(c => '<li><div class="nm"><b>' + esc(c.name) + '</b> ' + sub(c, cat) +
      (c.external_url ? ' <a href="' + esc(c.external_url) + '" target="_blank" rel="noopener noreferrer">Ouvrir ↗</a>' : '') +
      '</div><span class="pc">' + pct(c) + '</span><button class="vt" data-cat="' + cat.id + '" data-id="' + c.id + '">Voter</button></li>').join('');
    return '<section class="cat"><h2>' + esc(cat.name) + '</h2>' + (w ? '<div class="winners">' + w + '</div>' : '') + cube +
      (n ? '<ul class="rows">' + rows + '</ul>' : '<p class="muted">De nouveaux candidats arrivent bientôt.</p>') + '</section>';
  }).join('');
  paint();
  if (matchMedia('(prefers-reduced-motion: reduce)').matches) return;
  document.querySelectorAll('.cube').forEach((el, k) => {
    const list = lists[el.dataset.cat], n = list.length;
    if (n < 2) return;
    const fs = el.querySelectorAll('.face');
    let tick = 0, angle = 0;
    setTimeout(() => timers.push(setInterval(() => {
      const next = (tick + 1) % 4;
      fs[next].innerHTML = face(list[(tick + 1) % n]);
      angle -= 90; tick++;
      el.style.transform = 'translateZ(calc(var(--cw) / -2)) rotateY(' + angle + 'deg)';
    }, 4500)), k * 700);
  });
}

function paint() {
  document.querySelectorAll('.vt').forEach(b => {
    const on = choices[b.dataset.cat] === b.dataset.id;
    b.classList.toggle('on', on);
    b.textContent = on ? 'Choisi ✓' : 'Voter';
  });
  const n = Object.keys(choices).length;
  $('#votebar').hidden = !n;
  $('#review').textContent = 'Vérifier mon bulletin (' + n + ')';
}

async function load() {
  if (!C.SUPABASE_URL || !C.SUPABASE_ANON_KEY) { note('Le site n’est pas encore configuré (fichier js/config.js).'); return; }
  try {
    const now = encodeURIComponent(new Date().toISOString());
    const [s, c, k, w] = await Promise.all([
      get('settings?select=*&id=eq.1'),
      get('categories?select=*&order=sort_order.asc,created_at.asc'),
      get('candidates?select=*&order=sort_order.asc,created_at.asc'),
      get('winners?select=*&visible_until=gt.' + now + '&period_end=lte.' + now)
    ]);
    settings = s[0] || {}; cats = c; cands = k; wins = w; res = {};
    (await rpc('public_results', { p_period: 'week' })).forEach(x => { res[x.candidate_id] = x; });
    $('#note').hidden = true;
    render();
  } catch (e) { note('Impossible de charger les données. Vérifiez votre connexion.'); }
}
function note(t) { const n = $('#note'); n.textContent = t; n.hidden = false; }

// --- Fenêtres ---
let chatTimer = null;
const open = id => {
  $('#' + id).hidden = false;
  if (id === 'm-apply') applyLinks();
  if (id === 'm-chat') { chatLoad(); chatTimer = setInterval(chatLoad, 15000); }
  if (id === 'm-confirm') confirmView();
};
const closeAll = () => { document.querySelectorAll('.modal').forEach(m => { m.hidden = true; }); clearInterval(chatTimer); };
document.addEventListener('click', e => {
  const o = e.target.closest('[data-open]');
  if (o) { open(o.dataset.open); return; }
  if (e.target.closest('[data-close]') || e.target.classList.contains('modal')) closeAll();
});
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeAll(); });

// --- POSTULER ---
function applyLinks() {
  const d = String(settings.whatsapp || '').replace(/\D/g, ''), m = String(settings.email || '').trim();
  const wa = $('#wa'), ml = $('#mail');
  wa.hidden = !d; ml.hidden = !m;
  if (d) wa.href = 'https://wa.me/' + d + '?text=' + encodeURIComponent('POSTULER');
  if (m) ml.href = 'mailto:' + m + '?subject=' + encodeURIComponent('POSTULER');
  $('#apply-none').hidden = !!(d || m);
}

// --- Vote ---
$('#cats').addEventListener('click', e => {
  const b = e.target.closest('.vt'); if (!b) return;
  const { cat, id } = b.dataset;
  if (choices[cat] === id) delete choices[cat]; else choices[cat] = id;
  paint();
});
$('#review').addEventListener('click', () => open('m-confirm'));

let tsToken = '', tsId = null, sent = false;
function setMsg(t, k) { const m = $('#vmsg'); m.textContent = t || ''; m.className = 'msg ' + (k || ''); }
function confirmView() {
  setMsg('');
  $('#clist').innerHTML = Object.keys(choices).map(cid => {
    const cat = cats.find(c => c.id === cid), cd = cands.find(c => c.id === choices[cid]);
    return '<li><b>' + esc(cat ? cat.name : '') + '</b> : ' + esc(cd ? cd.name : '') + '</li>';
  }).join('');
  $('#confirm').hidden = sent;
  if (C.TURNSTILE_SITE_KEY && tsId === null) {
    const go = () => { tsId = turnstile.render('#ts', { sitekey: C.TURNSTILE_SITE_KEY, callback: t => { tsToken = t; }, 'expired-callback': () => { tsToken = ''; } }); };
    if (window.turnstile) go();
    else { const s = document.createElement('script'); s.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit'; s.async = true; s.onload = go; document.head.appendChild(s); }
  }
}
$('#confirm').addEventListener('click', async () => {
  const btn = $('#confirm');
  if (btn.disabled || !Object.keys(choices).length) return;
  if (C.TURNSTILE_SITE_KEY && !tsToken) { setMsg('Vérification anti-robot en cours, patientez un instant.', 'err'); return; }
  btn.disabled = true; setMsg('Envoi en cours…');
  try {
    const r = await fn('vote', { device_id: myId('limb_device', 'd-'), choices, token: tsToken });
    if (r.code === 200 && r.ok) {
      setMsg('Votre vote a été enregistré. Merci !', 'ok');
      Object.keys(choices).forEach(k => delete choices[k]);
      sent = true; btn.hidden = true; paint(); load();
    } else setMsg(r.message || 'Vote refusé. Réessayez plus tard.', 'err');
  } catch (e) { setMsg('Connexion impossible. Réessayez.', 'err'); }
  if (window.turnstile && tsId !== null) { turnstile.reset(tsId); tsToken = ''; }
  btn.disabled = false;
});
document.querySelectorAll('[data-close]').forEach(b => b.addEventListener('click', () => { sent = false; }));

// --- Messages avec l'administrateur ---
async function chatLoad() {
  try {
    const r = await fn('chat', { key: myId('limb_chat', 'c-'), action: 'list' });
    const box = $('#chatlog');
    box.innerHTML = (r.messages || []).map(m => '<div class="b ' + (m.sender === 'admin' ? 'a' : 'v') + '">' + esc(m.body) +
      '<time>' + new Date(m.created_at).toLocaleString('fr-FR', { dateStyle: 'short', timeStyle: 'short' }) + '</time></div>').join('') ||
      '<p class="muted">Écrivez votre message à l’administrateur.</p>';
    box.scrollTop = box.scrollHeight;
  } catch (e) {}
}
$('#chatsend').addEventListener('click', async () => {
  const t = $('#chattext'), b = $('#chatsend'), body = t.value.trim();
  if (!body || b.disabled) return;
  b.disabled = true;
  try {
    const r = await fn('chat', { key: myId('limb_chat', 'c-'), action: 'send', body });
    if (r.code === 200) { t.value = ''; await chatLoad(); } else $('#chatmsg').textContent = r.message || 'Message non envoyé.';
  } catch (e) { $('#chatmsg').textContent = 'Connexion impossible.'; }
  b.disabled = false;
});

// --- Installation (PWA) ---
let dp = null;
addEventListener('beforeinstallprompt', e => { e.preventDefault(); dp = e; });
if (matchMedia('(display-mode: standalone)').matches || navigator.standalone) $('#install').hidden = true;
addEventListener('appinstalled', () => { $('#install').hidden = true; });
$('#install').addEventListener('click', async () => {
  if (dp) { dp.prompt(); await dp.userChoice; dp = null; } else open('m-install');
});
if ('serviceWorker' in navigator) addEventListener('load', () => navigator.serviceWorker.register('sw.js').catch(() => {}));

// --- Accès administrateur discret : double clic (ou double tape) sur « App » ---
let last = 0;
$('#secret').addEventListener('click', () => { const n = Date.now(); if (n - last < 450) location.href = 'admin/'; last = n; });

$('#week').textContent = weekLabel();
load();
})();
