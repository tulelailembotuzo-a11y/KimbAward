// Seules des valeurs PUBLIQUES vont ici. Ne mettez JAMAIS de clé secrète (service_role) dans ce fichier.
window.LIMB = {
  SUPABASE_URL: "",          // ex. https://abcdxyz.supabase.co  (Supabase > Project Settings > API)
  SUPABASE_ANON_KEY: "",     // clé « anon / publishable »
  TURNSTILE_SITE_KEY: "",    // clé de site Cloudflare Turnstile (laisser vide pour désactiver)
  ADMIN_NAME: "LimbApp Admin",
  ADMIN_EMAIL: ""            // e-mail du compte admin créé dans Supabase > Authentication
};
